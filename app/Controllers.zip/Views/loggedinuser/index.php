<!doctype html>
<html lang="en" class="no-js">

<head>
    <?php include('header.php'); ?>
</head>

<body>
    <div class="ts-main-content">
        <?php include('sidebar.php'); ?>
        <?php include $page_name . '.php' ?>
    </div>
</body>

<footer>
    <?php include('footer.php'); ?>
</footer>

</html>